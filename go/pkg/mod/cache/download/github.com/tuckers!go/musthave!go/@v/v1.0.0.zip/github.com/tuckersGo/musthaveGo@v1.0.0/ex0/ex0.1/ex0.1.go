//ex0/ex0.1/ex0.1.go
package main

import "fmt"

func main() {
	fmt.Println("Hello World")
}
