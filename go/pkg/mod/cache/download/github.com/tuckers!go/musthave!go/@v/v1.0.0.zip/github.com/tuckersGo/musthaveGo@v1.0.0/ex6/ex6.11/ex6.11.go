//ex6/ex6.11/ex6.11.go
package main

import "fmt"

func main() {
	fmt.Println(3*4^7<<2+3*5 == 7) // ❶
}
