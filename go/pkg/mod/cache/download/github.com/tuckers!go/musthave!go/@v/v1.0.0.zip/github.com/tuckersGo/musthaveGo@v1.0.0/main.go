package main

import "fmt"

func main() {
	fmt.Println("This is tucker's Must have go examples.")
}
