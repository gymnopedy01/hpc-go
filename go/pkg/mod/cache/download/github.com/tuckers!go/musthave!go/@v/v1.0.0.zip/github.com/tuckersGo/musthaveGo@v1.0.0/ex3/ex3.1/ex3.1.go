//ex3/ex3.1/ex3.1.go
package main

import "fmt"

func main() {
	// Hello Go World 출력
	fmt.Println("Hello Go World")
}
